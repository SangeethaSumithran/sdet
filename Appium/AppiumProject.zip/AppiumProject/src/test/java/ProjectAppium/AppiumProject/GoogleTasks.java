package ProjectAppium.AppiumProject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class GoogleTasks {
	
AppiumDriver<MobileElement> driver = null;
	
	@BeforeClass
	public void setup() throws MalformedURLException
	{
		DesiredCapabilities descap = new DesiredCapabilities();
		descap.setCapability("deviceId", "emulator-5554");
		descap.setCapability("deviceName", "EmulatorPixel4");
		descap.setCapability("platformName", "Android");
		descap.setCapability("appPackage", "com.google.android.apps.tasks");
		descap.setCapability("appActivity", "com.google.android.apps.tasks.ui.TaskListsActivity");
		URL serverurl = new URL("http://127.0.0.1:4723/wd/hub");
		driver = new AndroidDriver<MobileElement>(serverurl, descap);
		
		
	}
	
	@Test
	public void googletask() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String task1 = "Complete Activity with Google Tasks";
		String task2 = "Complete Activity with Google Keep";
		String task3 = "Complete the second Activity Google Keep";
		driver.findElementById("com.google.android.apps.tasks:id/welcome_get_started").click();
		
		driver.findElementByAccessibilityId("Create new task").click();
		driver.findElementByXPath("//android.widget.EditText[@text='New task']").sendKeys(task1);
		driver.findElementById("com.google.android.apps.tasks:id/add_task_done").click();
		
		driver.findElementByAccessibilityId("Create new task").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//android.widget.EditText[@text='New task']").sendKeys(task2);
		driver.findElementById("com.google.android.apps.tasks:id/add_task_done").click();
		
		driver.findElementByAccessibilityId("Create new task").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//android.widget.EditText[@text='New task']").sendKeys(task3);
		driver.findElementById("com.google.android.apps.tasks:id/add_task_done").click();
		String[] list = {task3, task2, task1 };  
		Thread.sleep(2000);
		List<MobileElement> tasks = driver.findElementsByXPath("//android.widget.LinearLayout/android.widget.TextView");
		
		for (MobileElement task : tasks)
		{
			String value = task.getText();
			for (String ls : list)
			{
				if(value.equalsIgnoreCase(ls))
				{
					Assert.assertTrue(true, ls);
				}
			}
		}
		
		
	}
	@AfterClass
	public void teardown()
	{
		driver.quit();
	}
	
	

}
