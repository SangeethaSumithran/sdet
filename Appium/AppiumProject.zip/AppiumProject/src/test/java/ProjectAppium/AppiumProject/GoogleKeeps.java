package ProjectAppium.AppiumProject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class GoogleKeeps {
	
AppiumDriver<MobileElement> driver = null;
	
	@BeforeClass
	public void setup() throws MalformedURLException
	{
		DesiredCapabilities descap = new DesiredCapabilities();
		descap.setCapability("deviceId", "emulator-5554");
		descap.setCapability("deviceName", "EmulatorPixel4");
		descap.setCapability("platformName", "Android");
		descap.setCapability("appActivity", "com.android.chrome.com.google.android.apps.chrome.Main");
		descap.setCapability("noReset", true);
		descap.setCapability("browserName", "Chrome");
		URL serverurl = new URL("http://127.0.0.1:4723/wd/hub");
		driver = new AndroidDriver<MobileElement>(serverurl, descap);
		
		
	}
	
	@Test
	public void googlekeeps()
	{
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElementByAccessibilityId("New text note").click();
		driver.findElementById("com.google.android.keep:id/editable_title").sendKeys("Google Keeps");
		driver.findElementById("com.google.android.keep:id/edit_note_text").sendKeys("Complete this activity");
		driver.findElementByAccessibilityId("Open navigation drawer").click();
		String notetitle = driver.findElementById("com.google.android.keep:id/index_note_title").getText();
		Assert.assertEquals(notetitle, "Google Keeps");
		
	}
	@Test
	public void googlekeepsreminder() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElementByAccessibilityId("New text note").click();
		driver.findElementById("com.google.android.keep:id/editable_title").sendKeys("Google Keeps two");
		driver.findElementById("com.google.android.keep:id/edit_note_text").sendKeys("Complete this second activity");
		driver.findElementByAccessibilityId("Reminder").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//android.support.v7.widget.RecyclerView/android.view.ViewGroup[1]").click();
		driver.findElementByAccessibilityId("Open navigation drawer").click();
		
		String remindertime = driver.findElementById("com.google.android.keep:id/reminder_chip_text").getText();
		
		if (remindertime.contains("Today"))
		{
			Assert.assertTrue(true);
		}
		
	}
	
	
	
	
	
}
