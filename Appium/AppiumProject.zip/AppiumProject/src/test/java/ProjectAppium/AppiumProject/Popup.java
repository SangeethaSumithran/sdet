package ProjectAppium.AppiumProject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class Popup {

AppiumDriver<MobileElement> driver = null;
	
	@BeforeClass
	public void setup() throws MalformedURLException
	{
		DesiredCapabilities descap = new DesiredCapabilities();
		descap.setCapability("deviceId", "emulator-5554");
		descap.setCapability("deviceName", "EmulatorPixel4");
		descap.setCapability("platformName", "android");
		descap.setCapability("appActivity", "com.android.chrome.com.google.android.apps.chrome.Main");
		descap.setCapability("noReset", true);
		descap.setCapability("browserName", "Chrome");
		URL serverurl = new URL("http://0.0.0.0:4723/wd/hub");
		driver = new AndroidDriver<MobileElement>(serverurl, descap);
		driver.get("https://www.training-support.net/selenium");
	}
	
	@Test
	public void popupvalidcredentials() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		   jse.executeScript("window.scrollBy(0,2200)", "");
		Thread.sleep(2000);
 	    driver.findElementByXPath("//a[@href=\"/selenium/popups\"]").click(); 
		Thread.sleep(2000);
    	driver.findElementByXPath("//button[@class=\"ui huge inverted orange button\"]").click();
		driver.findElementByXPath("//input[@id='username']").sendKeys("admin");
		driver.findElementByXPath("//input[@id='password']").sendKeys("password");
		Thread.sleep(2000);
		driver.findElementByXPath("//button[@class=\"ui green button\"]").click();
		String loginvalidtext = driver.findElementByXPath("//div[@id=\"action-confirmation\"]").getText();
		Assert.assertEquals(loginvalidtext, "Welcome Back, admin");
	}
 @Test
	public void popupinvalidcredentials() throws InterruptedException
	{
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		   jse.executeScript("window.scrollBy(0,2200)", "");
		Thread.sleep(2000);
	    driver.findElementByXPath("//a[@href=\"/selenium/popups\"]").click(); 
		Thread.sleep(2000);
 	driver.findElementByXPath("//button[@class=\"ui huge inverted orange button\"]").click();
		driver.findElementByXPath("//input[@id='username']").sendKeys("admin");
		driver.findElementByXPath("//input[@id='password']").sendKeys("abc");
		Thread.sleep(2000);
		driver.findElementByXPath("//button[@class='ui green button']").click();
		String logininvalidtext = driver.findElementByXPath("//div[@id=\"action-confirmation\"]").getText();
		Assert.assertEquals(logininvalidtext, "Invalid Credentials");
	}
	
	@AfterClass
	public void teardown()
	{
		driver.quit();
	} 
}
