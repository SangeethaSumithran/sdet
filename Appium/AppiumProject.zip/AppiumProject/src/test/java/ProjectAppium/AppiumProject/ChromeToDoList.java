package ProjectAppium.AppiumProject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class ChromeToDoList {
	AppiumDriver<MobileElement> driver = null;
	
	@BeforeClass
	public void setup() throws MalformedURLException
	{
		DesiredCapabilities descap = new DesiredCapabilities();
		descap.setCapability("deviceId", "emulator-5554");
		descap.setCapability("deviceName", "EmulatorPixel4");
		descap.setCapability("platformName", "Android");
		descap.setCapability("noReset", true);
		descap.setCapability("browserName", "Chrome");
		descap.setCapability("appActivity", "com.android.chrome.com.google.android.apps.chrome.Main");
		URL serverurl = new URL("http://0.0.0.0:4723/wd/hub");
		driver = new AndroidDriver<MobileElement>(serverurl, descap);
		driver.get("https://www.training-support.net/selenium");
		
	}
	
	@Test
	public void chrometodolist() throws InterruptedException
	{
		Thread.sleep(2000);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		   jse.executeScript("window.scrollBy(0,1800)", "");
	Thread.sleep(2000);
 	   driver.findElementByXPath("//a[@href=\"/selenium/todo-list\"]").click(); 
 	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		MobileElement taskinput = driver.findElementByXPath("//input[@id=\"taskInput\"]");
		taskinput.sendKeys("First task");
		driver.findElementByXPath("//button[@class='ui blue button']").click();
		taskinput.sendKeys("Second task");
		driver.findElementByXPath("//button[@class='ui blue button']").click();
		taskinput.sendKeys("Third task");
		driver.findElementByXPath("//button[@class='ui blue button']").click();
		Thread.sleep(2000);
		List<MobileElement> chrometodo = driver.findElementsByXPath("//div[@class=\"item\"]");
		int tasksize = chrometodo.size();
		Assert.assertEquals(tasksize, 4);
		
		for (MobileElement todo : chrometodo )
		{
			todo.click();
		}
		
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class=\"ui red bottom attached button\"]").click();
		boolean taskdelete = driver.findElementByXPath("//div[@class=\"item\"]").isDisplayed();
		
		Assert.assertEquals(taskdelete, false);
		
		
	}
		
	

}
