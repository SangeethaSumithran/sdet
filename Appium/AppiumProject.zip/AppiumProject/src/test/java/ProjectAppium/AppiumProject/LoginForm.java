package ProjectAppium.AppiumProject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.DesiredCapabilities;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;



import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;







public class LoginForm
{
AppiumDriver<MobileElement> driver = null;
WebDriverWait wait;


	
	@BeforeMethod
	public void setup() throws MalformedURLException
	{
		DesiredCapabilities descap = new DesiredCapabilities();
		
		descap.setCapability("deviceName", "EmulatorPixel4");
		descap.setCapability("platformName", "Android");
		descap.setCapability("browserName", "Chrome");
		descap.setCapability("appActivity", "com.android.chrome.com.google.android.apps.chrome.Main");
		descap.setCapability("noReset", false);
		descap.setCapability("automationName", "UiAutomator2");
		

		URL serverurl = new URL("http://0.0.0.0:4723/wd/hub");
		driver = new AndroidDriver<MobileElement>(serverurl, descap);
		wait = new WebDriverWait(driver, 5);
		driver.get("https://www.training-support.net/selenium");
		
		
	}
	
	@Test
	public void loginformvalidcreds() throws InterruptedException 
	{
		
		Thread.sleep(4000);
		
		
		//driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(4)"));
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		   jse.executeScript("window.scrollBy(0,1200)", "");
		Thread.sleep(2000);
    	driver.findElementByXPath("//a[@href=\"/selenium/login-form\"]").click(); 
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElementByXPath("//input[@id=\"username\"]").sendKeys("admin");
		driver.findElementByXPath("//input[@id=\"password\"]").sendKeys("password");
		Thread.sleep(4000);
		driver.findElementByXPath("//button[@class=\"ui button\"]").click();
		String loginvalidmessage = driver.findElementByXPath("//div[@id=\"action-confirmation\"]").getText();
		Assert.assertEquals(loginvalidmessage, "Welcome Back, admin");
	}

	 @Test
	public void loginforminvalidcreds() throws InterruptedException
	{
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		   jse.executeScript("window.scrollBy(0,1200)", "");
		Thread.sleep(2000);
    	driver.findElementByXPath("//a[@href=\"/selenium/login-form\"]").click(); 
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElementByXPath("//input[@id=\"username\"]").sendKeys("one");
		driver.findElementByXPath("//input[@id=\"password\"]").sendKeys("two");
		Thread.sleep(4000);
		driver.findElementByXPath("//button[@class=\"ui button\"]").click();
		String logininvalidmessage = driver.findElementByXPath("//div[@id=\"action-confirmation\"]").getText();
		Assert.assertEquals(logininvalidmessage, "Invalid Credentials");
	}
	
	@AfterMethod
	public void teardown()
	{
		
		driver.quit();
	} 
	
	
}

