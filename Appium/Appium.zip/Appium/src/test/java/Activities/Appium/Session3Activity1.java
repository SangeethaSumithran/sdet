package Activities.Appium;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class Session3Activity1 {
AppiumDriver<MobileElement> driver = null;
	
	@BeforeClass
	public void setup() throws MalformedURLException
	{
		DesiredCapabilities descap = new DesiredCapabilities();
		descap.setCapability("deviceId", "emulator-5554");
		descap.setCapability("deviceName", "EmulatorPixel4");
		descap.setCapability("platformName", "android");
		descap.setCapability("appPackage", "com.google.android.apps.messaging");
		descap.setCapability("appActivity", "com.google.android.apps.messaging.ui.ConversationListActivity");
		URL serverurl = new URL("http://0.0.0.0:4723/wd/hub");
		driver = new AndroidDriver<MobileElement>(serverurl, descap);
		
	}
	
	@Test
	public void smsactivity()
	{
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElementById("com.google.android.apps.messaging:id/start_new_conversation_button").click();
		driver.findElementByXPath("//android.widget.TextView[@content-desc=\"Nine Five Three Five Five Zero Six Nine Four Seven \"]").click();
		
		driver.findElementById("com.google.android.apps.messaging:id/compose_message_text").sendKeys("Hello from Appium");
		driver.findElementById("com.google.android.apps.messaging:id/send_message_button_icon").click();
		String message = driver.findElementById("com.google.android.apps.messaging:id/message_text").getText();
		Assert.assertEquals(message, "Hello from Appium");
		
		
		
		
	}
	
	@AfterClass
	public void teardown()
	{
		driver.quit();
	}
	

}


