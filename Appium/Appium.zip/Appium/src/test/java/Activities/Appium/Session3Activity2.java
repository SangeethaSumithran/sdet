package Activities.Appium;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.remote.DesiredCapabilities;


import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class Session3Activity2 {
AppiumDriver<MobileElement> driver = null;

	
	@BeforeClass
	public void setup() throws MalformedURLException
	{
		DesiredCapabilities descap = new DesiredCapabilities();
		descap.setCapability("deviceId", "emulator-5554");
		descap.setCapability("deviceName", "EmulatorPixel4");
		descap.setCapability("platformName", "Android");
		descap.setCapability("browserName", "Chrome");
		descap.setCapability("appActivity", "com.android.chrome.com.google.android.apps.chrome.Main");
		descap.setCapability("noReset", true);
		URL serverurl = new URL("http://0.0.0.0:4723/wd/hub");
		driver = new AndroidDriver<MobileElement>(serverurl, descap);
		
		
		
	}
	
	@Test
	    public void imageScrollTest() throws InterruptedException {
		
		driver.get("https://www.training-support.net/selenium/lazy-loading");
		Thread.sleep(5000);
		
		
        List<MobileElement> numberOfImages = driver.findElementsByXPath("//android.view.View/android.view.View/android.widget.Image");
        System.out.println("Number of image shown currently: " + numberOfImages.size());
        
        
        Assert.assertEquals(numberOfImages.size(), 4);
        
        
        driver.findElement(MobileBy.AndroidUIAutomator("UiScrollable(UiSelector()).scrollTextIntoView(\"helen\")"));
        
        List<MobileElement> newnumber = driver.findElementsByXPath("//android.view.View/android.view.View/android.widget.Image");
        System.out.println("Number of image shown currently: " + newnumber.size());
        Assert.assertEquals(newnumber.size(), 4);
    }
 
    @AfterClass
    public void afterClass()
    {
        driver.quit();
    }

	    
	        
	        
	      
	        
	        
	       
	    
	}

