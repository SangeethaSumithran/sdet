package Activities.Appium;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class Session2Activity3 {
AppiumDriver<MobileElement> driver = null;
	
	@BeforeClass
	public void setup() throws MalformedURLException
	{
		DesiredCapabilities descap = new DesiredCapabilities();
		descap.setCapability("deviceId", "emulator-5554");
		descap.setCapability("deviceName", "EmulatorPixel4");
		descap.setCapability("platformName", "android");
		descap.setCapability("appPackage", "com.android.contacts");
		descap.setCapability("appActivity", "com.android.contacts.activities.PeopleActivity");
		URL serverurl = new URL("http://0.0.0.0:4723/wd/hub");
		driver = new AndroidDriver<MobileElement>(serverurl, descap);
		
		
	}
	
	@Test
	public void contacts()
	{
	
		driver.findElementByAccessibilityId("Create new contact").click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElementById("com.android.contacts:id/left_button").click();
		driver.findElementByXPath("//android.widget.EditText[@text='First name']").sendKeys("Aaditya");
		driver.findElementByXPath("//android.widget.EditText[@text='Last name']").sendKeys("Varma");
		driver.findElementByXPath("//android.widget.EditText[@text='Phone']").sendKeys("999148292");
		driver.findElementById("com.android.contacts:id/editor_menu_save_button").click();
		String contactname = driver.findElementById("com.android.contacts:id/large_title").getText();
		Assert.assertEquals(contactname, "Aaditya Varma");
	}

	@AfterClass
	public void teardown()
	{
		driver.quit();
	}
	
	
	}




