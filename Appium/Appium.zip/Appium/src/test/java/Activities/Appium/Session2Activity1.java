package Activities.Appium;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;


import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class Session2Activity1 {
AppiumDriver<MobileElement> driver = null;
	
	@BeforeClass
	public void setup() throws MalformedURLException
	{
		DesiredCapabilities descap = new DesiredCapabilities();
		descap.setCapability("deviceId", "emulator-5554");
		descap.setCapability("deviceName", "EmulatorPixel4");
		descap.setCapability("platformName", "Android");
		descap.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
		descap.setCapability("automationName", "UiAutomator2");
		URL serverurl = new URL("http://0.0.0.0:4723/wd/hub");
		driver = new AndroidDriver<MobileElement>(serverurl, descap);
		
	}
	
	@Test
	public void testcase() throws InterruptedException
	{
		driver.get("https://www.training-support.net/");
		
		Thread.sleep(4000);
		
		List<MobileElement> elementsList=driver.findElementsByClassName("android.view.View");
		for(MobileElement mobe: elementsList)
		{
			if(mobe.getText().equals("Training Support"))
			{
				String title = mobe.getText();
				System.out.println("The title of the page is :" +title);
				Assert.assertEquals(title, "Training Support");
			}
		}
		for(MobileElement mobe: elementsList)
		{
			if(mobe.getText().equals("About Us"))
			{
				String newtitle = mobe.getText();
				System.out.println("The title of the page is :" +newtitle);
				Assert.assertEquals(newtitle, "About Us");
			}
		}
		
	}
	
	@AfterClass
	public void teardown()
	{
		driver.quit();
	}

	
	
	
	}
	


