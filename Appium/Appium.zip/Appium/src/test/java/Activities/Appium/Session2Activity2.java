package Activities.Appium;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class Session2Activity2 {
	
	AppiumDriver<MobileElement> driver = null;
	
	@BeforeClass
	public void setup() throws MalformedURLException
	{
		DesiredCapabilities descap = new DesiredCapabilities();
		descap.setCapability("deviceId", "emulator-5554");
		descap.setCapability("deviceName", "EmulatorPixel4");
		descap.setCapability("platformName", "android");
		descap.setCapability("appPackage", "com.android.calculator2");
		descap.setCapability("appActivity", "com.android.calculator2.Calculator");
		URL serverurl = new URL("http://127.0.0.1:4723/wd/hub");
		driver = new AndroidDriver<MobileElement>(serverurl, descap);
		
		
	}
	
	@Test
	public void add()
	{
	 driver.findElementById("com.android.calculator2:id/digit_5").click();
	 driver.findElementById("com.android.calculator2:id/op_add").click();
	 driver.findElementById("com.android.calculator2:id/digit_9").click();
	 driver.findElementById("com.android.calculator2:id/eq").click();
	 String Addresult = driver.findElementById("com.android.calculator2:id/result").getText();
	 System.out.println("The Addition result is : " +Addresult);
	 Assert.assertEquals(Addresult, "14");
	 	
		
	}
	
	 @Test
	public void sub()
	{
	
	 driver.findElementById("com.android.calculator2:id/digit_1").click();
	 driver.findElementById("com.android.calculator2:id/digit_0").click();
	 driver.findElementById("com.android.calculator2:id/op_sub").click();
	 driver.findElementById("com.android.calculator2:id/digit_5").click();
	 driver.findElementById("com.android.calculator2:id/eq").click();
	 String subresult = driver.findElementById("com.android.calculator2:id/result").getText();
	 System.out.println("The Sub result is : " +subresult);
	 Assert.assertEquals(subresult, "5");
	 
		 
	}
	
	@Test
	public void multiply()
	{
		
		 driver.findElementById("com.android.calculator2:id/digit_5").click();
		 driver.findElementById("com.android.calculator2:id/op_mul").click();
		 driver.findElementById("com.android.calculator2:id/digit_1").click();
		 driver.findElementById("com.android.calculator2:id/digit_0").click();
		 driver.findElementById("com.android.calculator2:id/digit_0").click();
		 driver.findElementById("com.android.calculator2:id/eq").click();
		 String mulresult = driver.findElementById("com.android.calculator2:id/result").getText();
		 System.out.println("The mul result is : " +mulresult);
		 Assert.assertEquals(mulresult, "500");
		
	}
	
	@Test
	public void div()
	{
		 driver.findElementById("com.android.calculator2:id/digit_5").click();
		 driver.findElementById("com.android.calculator2:id/digit_0").click();
		 driver.findElementById("com.android.calculator2:id/op_div").click();
		 driver.findElementById("com.android.calculator2:id/digit_2").click();
		 driver.findElementById("com.android.calculator2:id/eq").click();
		 String divresult = driver.findElementById("com.android.calculator2:id/result").getText();
		 System.out.println("The div result is : " +divresult);
		 Assert.assertEquals(divresult, "25");
		
	}
	
	@AfterClass
	public void afterclass()
	{
		driver.quit();
	}
	
	
	
	}



