package Activities.Appium;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class Session1Activity {
	@Test
	public void calculator () throws InterruptedException, IOException{
		DesiredCapabilities descap = new DesiredCapabilities();
		descap.setCapability("deviceId", "emulator-5554");
		descap.setCapability("deviceName", "EmulatorPixel4");
		descap.setCapability("platformName", "android");
		descap.setCapability("appPackage", "com.android.calculator2");
		descap.setCapability("appActivity", "com.android.calculator2.Calculator");
		
		AppiumDriver<MobileElement> driver = null ; 
		 try {

            // Initialize driver
           URL serverurl = new URL("http://0.0.0.0:4723/wd/hub");
           driver = new AndroidDriver<MobileElement>(serverurl, descap);

            System.out.println("Calculator is open");

        } catch (MalformedURLException e) {

            System.out.println(e.getMessage());

        }
		
		
	}
	
	

}
