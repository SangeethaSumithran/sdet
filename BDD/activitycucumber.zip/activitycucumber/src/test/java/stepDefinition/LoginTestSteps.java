package stepDefinition;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginTestSteps {

	WebDriver driver;
	
    @Given("^User is on Login page$")
    public void user_is_on_login_page() throws Throwable 
    {
    	System.setProperty("webdriver.gecko.driver", "C:\\Users\\SangeethaS\\Downloads\\geckodriver.exe");
		driver=new FirefoxDriver();	
		driver.get("https://www.training-support.net/selenium/login-form");
        
    }
    
   @When("^User enters \"(.*)\" and \"(.*)\"$")//without example
    public void user_enters(String user, String pass) throws Throwable 
    {
    	driver.findElement(By.xpath("//input[@id='username']")).sendKeys(user);
    	driver.findElement(By.xpath("//input[@id='password']")).sendKeys(pass);
        driver.findElement(By.xpath("//button[@class='ui button']")).click();
    } 

    @When("^User enters username and password$")
    public void user_enters_username_and_password() throws Throwable {
    	driver.findElement(By.xpath("//input[@id='username']")).sendKeys("admin");
    	driver.findElement(By.xpath("//input[@id='password']")).sendKeys("password");
        driver.findElement(By.xpath("//button[@class='ui button']")).click();
    }
   @When("^User enters the \"(.*)\" and \"(.*)\"$")//with examples
    public void user_enters_the(String Usernames, String Passwords) throws Throwable
    {
    	driver.findElement(By.xpath("//input[@id='username']")).sendKeys(Usernames);
    	driver.findElement(By.xpath("//input[@id='password']")).sendKeys(Passwords);
        driver.findElement(By.xpath("//button[@class='ui button']")).click();  
    } 

    @Then("^Read the page title and confirmation message$")
    public void read_the_page_title_and_confirmation_message() throws Throwable 
    {
    	String title = driver.getTitle();
    	System.out.println("The title of the page is : " +title);
    	String logintext = driver.findElement(By.xpath("//div[@id='action-confirmation']")).getText();
    	if(logintext.contains("admin"))
    	{
    		Assert.assertEquals(logintext, "Welcome Back, admin");
    	}
    	else
    	{
    		Assert.assertEquals(logintext, "Invalid Credentials");
    	}
       
    }

    @And("^Close the Browser$")
    public void close_the_browser() throws Throwable 
    {
      driver.close();
    }


}
