package Stepdefination;

import java.util.List;

import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;

import CucumberProject.AlchemyJobs.launchbrowser;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class searchjob extends launchbrowser{

	@Given("^Open browser and launch jobs search page$")
    public void open_browser_and_launch_jobs_search_page() throws Throwable 
	{
		driver = initialize();
		driver.get("https://alchemy.hguy.co/jobs/");
		driver.findElement(By.xpath("//li[@id='menu-item-24']/a")).click();
		Thread.sleep(2000);
    }
	 @And("^click on keyword search$")
	 public void click_on_keyword_search() throws Throwable 
	 {
	    driver.findElement(By.xpath("//input[@id='search_keywords']")).sendKeys("tester");
	    driver.findElement(By.xpath("//div[@class='search_submit']")).click();
	    Thread.sleep(2000);
	 }
	 
	 @And("^Change the job type to fulltime$")
	    public void change_the_job_type_to_fulltime() throws Throwable 
	 {
		 
		Thread.sleep(3000);
		 List<WebElement> jobtype = driver.findElements(By.xpath("//ul[@class='job_types']/li"));
		 int elesize = jobtype.size();
		 System.out.println(elesize);
		 for (WebElement jobs : jobtype)
		 {
			 String job = jobs.getText();
			 if(!job.contains("Full Time"))
			 {
		      jobs.click(); 
			 }
		 }
		 
		 
	       
	 }

    @When("^Find joblisting$")
    public void find_joblisting() throws Throwable 
    {
    	Thread.sleep(2000);
      driver.findElement(By.xpath("//div[@class='position']")).click();
     
    }
    
    @And("^Find the title of the job$")
    public void find_the_title_of_the_job() throws Throwable 
    {
    	 String entrytitle = driver.findElement(By.xpath("//h1[@class='entry-title']")).getText();
         System.out.println("The title of job is " +entrytitle);
    }

    @Then("^Click on Apply job$")
    public void click_on_apply_job() throws Throwable 
    {
        driver.findElement(By.xpath("//input[@class='application_button button']")).click();
    	
    }

   @And("^Close browser$")
    public void close_browser() throws Throwable 
    {
        driver.close();
    }

}
