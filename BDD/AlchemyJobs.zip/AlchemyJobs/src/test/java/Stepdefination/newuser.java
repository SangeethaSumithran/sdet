package Stepdefination;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;

import CucumberProject.AlchemyJobs.launchbrowser;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class newuser extends launchbrowser{
	
	
	 @Given("^Open browser and navigate to site$")
	    public void open_browser_and_navigate_to_site() throws Throwable 
	    {
		 
		 driver = initialize();
		 driver.get("https://alchemy.hguy.co/jobs/wp-admin");
		 driver.findElement(By.id("user_login")).sendKeys("root");
		 driver.findElement(By.id("user_pass")).sendKeys("pa$$w0rd");
		 driver.findElement(By.id("wp-submit")).click();
	    }

	    @When("^Click on Users$")
	    public void click_on_users() throws Throwable
	    {
	        driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/ul/li[11]/a/div[3]")).click();
	        
	    }
	    @And("^Locate the add new button$")
	    public void locate_the_add_new_button() throws Throwable 
	    {
	    	driver.findElement(By.xpath("//a[@class='page-title-action']")).click();
	    }

	    @Then("^Fill the necessary details$")
	    public void fill_the_necessary_details() throws Throwable 
	    {
	        driver.findElement(By.id("user_login")).sendKeys("aod");
	        driver.findElement(By.id("email")).sendKeys("aod@was.com");
	    }

	    @And("^Click on add new user$")
	    public void click_on_add_new_user() throws Throwable 
	    {
	    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        driver.findElement(By.id("createusersub")).click();
	    }
	    
	    @Then("^Verify the user is created$")
	    public void verify_the_user_is_created() throws Throwable 
	    {
	      driver.findElement(By.id("user-search-input")).sendKeys("aod");
	      driver.findElement(By.id("search-submit")).click();
	      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	      String user = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div[4]/form/table/tbody/tr/td[1]/strong/a")).getText();
	      Assert.assertEquals(user, "abd");
	    }

	   @And("^Close browser and generate report$")
	    public void close_browser_and_generate_report() throws Throwable 
	    {
	      driver.close();  
	    }

	}