package Stepdefination;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import CucumberProject.AlchemyJobs.jobpostelements;
import CucumberProject.AlchemyJobs.launchbrowser;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class jobpost extends launchbrowser
{
	public jobpostelements jp;
	 @Given("^Launch browser and launch jobs page$")
	    public void launch_browser_and_launch_jobs_page() throws Throwable 
	   
	    {
		    driver = initialize();
			driver.get("https://alchemy.hguy.co/jobs/");
			
	        
	    }
	 @And("^Go to post jobs$")
	    public void go_to_post_jobs() throws Throwable 
	    {
		 driver.findElement(By.xpath("//li[@id='menu-item-26']/a")).click();
		Thread.sleep(2000);  
	    }

	    @When("^Provide details")
	    public void Provide_details(DataTable table) throws Throwable 
	    {
	    	jp = new jobpostelements(driver);
	    	List<String> detail = table.asList();
	    	jp.emailjp().sendKeys(detail.get(0));
	    	jp.jtitlejp().sendKeys(detail.get(1));
	    	WebElement description= jp.iframejp();
			driver.switchTo().frame(description);
			jp.descjp().sendKeys(detail.get(2));
			driver.switchTo().defaultContent();
			jp.appemailjp().sendKeys(detail.get(3));
			jp.compjp().sendKeys(detail.get(4));
	        
	    }
	    
	    @When("^Provide emailid \"([^\"]*)\"$")
	    public void provide_emailid(String emailid) throws Throwable 
	    {
	    	jp = new jobpostelements(driver);
	    	
	    	jp.emailjp().sendKeys(emailid);
	    }
	    
	    
	    @And("^Job title \"([^\"]*)\"$")
	    public void job_title(String title, String jobt) throws Throwable 
	    {
	    	jp = new jobpostelements(driver);
	    	jp.jtitlejp().sendKeys(jobt); 
	    }
	    
	    
	    @And("^Description \"([^\"]*)\"$")
	    public void description(String des) throws Throwable 
	    {
	    	jp = new jobpostelements(driver);
	    	WebElement description= jp.iframejp();
			driver.switchTo().frame(description);
			jp.descjp().sendKeys(des);
			driver.switchTo().defaultContent();
			}
	    
	    
	    
	    @And("^Application email  \"([^\"]*)\"$")
	    public void application_email(String appel) throws Throwable 
	    {
	    	jp = new jobpostelements(driver);
	    	 jp.appemailjp().sendKeys(appel);
	    }

	    @And("^Company name  \"([^\"]*)\"$")
	    public void company_name(String comnme) throws Throwable
	    {
	    	jp = new jobpostelements(driver);
	    	jp.compjp().sendKeys(comnme);
	    }
	    
	    @Then("^Click on preview$")
	    public void click_on_preview() throws Throwable 
	    {
	       jp = new jobpostelements(driver);
	       jp.prebutjp().click();
	    }

	    

	    @And("^Submit listings$")
	    public void submit_listings() throws Throwable 
	    {
	    	jp = new jobpostelements(driver);
	        jp.subbutjp().click();
	    }
	    
	    @Then("^Confirm job listing is shown$")
	    public void confirm_job_listing_is_shown() throws Throwable 
	    {
	       jp = new jobpostelements(driver);
	       driver.findElement(By.xpath("/html/body/div[2]/div/div/div/main/article/div/a")).click();
	       String titlecheck = driver.findElement(By.xpath("//h1[@class='entry-title']")).getText();
	       Assert.assertEquals(titlecheck, "Tester");
	    }
	    
	   
        @And("^close browser$")
	    public void close_browser() throws Throwable
	    {
	       driver.close(); 
	    }


}
