package CucumberProject.AlchemyJobs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class jobpostelements
{
	public WebDriver driver;
	
	By email = By.xpath("//input[@id='create_account_email']");
	By jtitle = By.xpath("//input[@id='job_title']");
	By frame = By.id("job_description_ifr");
	By desc = By.xpath("//*[@id='tinymce']");
	By appemail = By.xpath("//input[@id='application']");
	By comp = By.xpath("//input[@id='company_name']");
	By prebut = By.xpath("//input[@class='button']");
	By subbut = By.xpath("//input[@id='job_preview_submit_button']");
	
	public jobpostelements(WebDriver driver) 
	{
		this.driver=driver; 
	}
	
	public WebElement emailjp()
	{
		return driver.findElement(email);
	}
	public WebElement jtitlejp()
	{
		return driver.findElement(jtitle);
	}
	public WebElement iframejp()
	{
		return driver.findElement(frame);
	}
	public WebElement descjp()
	{
		return driver.findElement(desc);
	}
	public WebElement appemailjp()
	{
		return driver.findElement(appemail);
	}
	public WebElement compjp()
	{
		return driver.findElement(comp);
	}
	public WebElement prebutjp()
	{
		return driver.findElement(prebut);
	}
	public WebElement subbutjp()
	{
		return driver.findElement(subbut);
	}
	
}
