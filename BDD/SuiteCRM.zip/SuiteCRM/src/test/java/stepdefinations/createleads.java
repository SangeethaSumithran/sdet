package stepdefinations;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import CucumberProject.SuiteCRM.newbase;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class createleads extends newbase{
	
	    @Given("^open browser and login \"([^\"]*)\" and \"([^\"]*)\"$")
	    public void open_browser_and_login_something_and_something(String user, String pass) throws Throwable 
	    {
	    	driver = initialize();
		    driver.get("https://alchemy.hguy.co/crm/"); 
		    driver.findElement(By.id("user_name")).sendKeys(user);
		    driver.findElement(By.id("username_password")).sendKeys(pass);
		    driver.findElement(By.id("bigbutton")).click();
	        
	    }
	    @And("^Navigate to create lead$")
	    public void navigate_to_create_lead() throws Throwable 
	    {
	    	Actions a=new Actions(driver);
	    	WebElement sales=driver.findElement(By.xpath("//a[@id='grouptab_0']"));
	    	a.moveToElement(sales).build().perform();
	    	WebElement leads = driver.findElement(By.xpath("//a[@id='moduleTab_9_Leads']"));
	    	a.moveToElement(leads).click().build().perform();
	    	Thread.sleep(1000);
	    	
	    }


	    @When("^Fill the details$")
	    public void fill_the_details(DataTable detail) throws Throwable
	    {
	    	driver.findElement(By.xpath("/html/body/div[3]/div/div/div[1]/ul/li[1]/a/div[2]")).click();
	    	Thread.sleep(2000);
	    	List<String> det = detail.asList();
	    	driver.findElement(By.id("first_name")).sendKeys(det.get(0));
	    	driver.findElement(By.id("last_name")).sendKeys(det.get(1));
	    	driver.findElement(By.id("EditView_account_name")).sendKeys(det.get(2));
	       
	    }
	    
	    @And("^Click save$")
	    public void click_save() throws Throwable 
	    {
	      driver.findElement(By.xpath("//input[@id='SAVE']")).click();  
	    }

	    @Then("^Navigate to view leads page to check result$")
	    public void navigate_to_view_leads_page_to_check_result() throws Throwable 
	    {
	        String name = driver.findElement(By.xpath("//h2[@class='module-title-text']")).getText();
	        Assert.assertEquals(name, "JACK JILL");
	    }

	    @And("^Browser to be closed$")
	    public void browser_to_be_closed() throws Throwable 
	    {
	        driver.close();
	    }

	}