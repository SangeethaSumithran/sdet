package stepdefinations;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import CucumberProject.SuiteCRM.newbase;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class dashletcount extends newbase{
	
	   @Given("^login to CRM with \"([^\"]*)\" and \"([^\"]*)\"$")
	    public void login_to_crm_with_something_and_something(String username, String password) throws Throwable 
	    {
		   driver = initialize();
	       driver.get("https://alchemy.hguy.co/crm/"); 
	       driver.findElement(By.id("user_name")).sendKeys(username);
	       driver.findElement(By.id("username_password")).sendKeys(password);
	       driver.findElement(By.id("bigbutton")).click();
	    }

	    @When("^Count the number of dashlets$")
	    public void count_the_number_of_dashlets() throws Throwable
	    {
	        List<WebElement> dashlet = driver.findElements(By.xpath("//ul[@id='col_0_1']/li[contains(@id,'dashlet')]"));
	        int dashsize = dashlet.size();
	        Assert.assertEquals(dashsize,4);
	    }

	    @Then("^Print the count$")
	    public void print_the_count() throws Throwable 
	    {
	    	List<WebElement> dashlet = driver.findElements(By.xpath("//ul[@id='col_0_1']/li[contains(@id,'dashlet')]"));
	    	int dashsize = dashlet.size();
	    	System.out.println("Number of Dashlets are : "+dashsize);
	    }

	    @And("^Close the browser$")
	    public void close_the_browser() throws Throwable 
	    {
	    	driver.close();
	    }
	

}
