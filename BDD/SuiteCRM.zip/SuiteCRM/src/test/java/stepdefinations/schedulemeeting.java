package stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import CucumberProject.SuiteCRM.newbase;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class schedulemeeting extends newbase{
	
	    @Given("^open browser for schedule meeting and login \"([^\"]*)\" and \"([^\"]*)\"$")
	    public void open_browser_for_schedule_meeting_and_login_something_and_something(String use, String pas) throws Throwable 
	    {
		   driver = initialize();
	       driver.get("https://alchemy.hguy.co/crm/"); 
	       driver.findElement(By.id("user_name")).sendKeys(use);
	       driver.findElement(By.id("username_password")).sendKeys(pas);
	       driver.findElement(By.id("bigbutton")).click(); 
	    }
	    
	    @And("^Navigate to schedule meeting$")
	    public void navigate_to_schedule_meeting() throws Throwable 
	    {
	    	Actions a=new Actions(driver);
	    	WebElement activities=driver.findElement(By.xpath("//a[@id='grouptab_3']"));
	    	a.moveToElement(activities).build().perform();
	    	WebElement meeting = driver.findElement(By.xpath("//a[@id='moduleTab_9_Meetings']"));
	    	a.moveToElement(meeting).click().build().perform();
	    	driver.findElement(By.xpath("//dic[@id='actionMenuSidebar']/li[1]")).click();  
	    }

	    @When("^Enter meeting details$")
	    public void enter_meeting_details() throws Throwable 
	    {
	       driver.findElement(By.xpath("//input[id='name']")).sendKeys("Project discussion");
	    }
	    
	    @And("^Search members \"([^\"]*)\" and add them$")
	    public void search_members_something_and_add_them(String fname) throws Throwable 
	    {
	       driver.findElement(By.id("search_first_name")).sendKeys(fname);
	       driver.findElement(By.id("invitees_search")).click();
	       driver.findElement(By.id("invitees_add_1")).click();
	    }
	    
	    @And("^Save$")
	    public void save() throws Throwable {
	       driver.findElement(By.id("SAVE_HEADER")).click();
	    }

	    @Then("^confirm if meeting is created$")
	    public void confirm_if_meeting_is_created() throws Throwable 
	    {
	       String sub = driver.findElement(By.xpath("//div[@class='moduleTitle']")).getText();
	       Assert.assertEquals(sub, "Project discussion");
	    }

	    @And("^make sure to close the browser$")
	    public void make_sure_to_close_the_browser() throws Throwable
	    {
	       driver.close();
	    }

	
}
	
	  