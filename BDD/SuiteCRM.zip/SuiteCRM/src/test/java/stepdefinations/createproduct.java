package stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import CucumberProject.SuiteCRM.newbase;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class createproduct extends newbase{
	
	   @Given("^login CRM with \"([^\"]*)\" and \"([^\"]*)\"$")
	    public void login_crm_with_something_and_something(String usn, String psw) throws Throwable 
	    {
		   driver = initialize();
		    driver.get("https://alchemy.hguy.co/crm/"); 
		    driver.findElement(By.id("user_name")).sendKeys(usn);
		    driver.findElement(By.id("username_password")).sendKeys(psw);
		    driver.findElement(By.id("bigbutton")).click();
	    }
	   
	   @And("^Navigate to create product$")
	    public void navigate_to_create_product() throws Throwable 
	    {
		   Actions a=new Actions(driver);
	       WebElement all=driver.findElement(By.xpath("//a[@id='grouptab_5']"));
	    	a.moveToElement(all).build().perform();
	    	WebElement product = driver.findElement(By.xpath("////ul[@class='dropdown-menu']/li[25]"));
	    	a.moveToElement(product).click().build().perform();
	    	driver.findElement(By.xpath("//div[@id='actionMenuSidebar']/li[1]")).click();
	    }

	    @When("^Enter product details \"([^\"]*)\" \"([^\"]*)\"  \"([^\"]*)\"$")
	    public void enter_product_details_something_something_something(String productname, String partnumber, String price) throws Throwable 
	    {
	       driver.findElement(By.id("name")).sendKeys(productname);
	       driver.findElement(By.id("part_number")).sendKeys(partnumber);
	       driver.findElement(By.id("price")).sendKeys(price);
	    }
	    
	    @And("^click on save$")
	    public void click_save1() throws Throwable 
	    {
	       driver.findElement(By.id("SAVE")).click();
	    }

	    @Then("^confirm if product is created$")
	    public void confirm_if_product_is_created() throws Throwable
	    {
	      String pname =  driver.findElement(By.xpath("//div[@class='moduleTitle']")).getText();
	      Assert.assertEquals(pname, "INS");
	    }


	    @And("^browser close$")
	    public void browser_close() throws Throwable 
	    {
	        driver.close();
	    }

	

}
