package CucumberProject.OrangeHRM;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class browser {
public WebDriver driver ;
	
	public WebDriver initialize()
	{
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\SangeethaS\\Downloads\\geckodriver.exe");
		driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		return driver;
		
	}

}
