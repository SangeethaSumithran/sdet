package stepDefinations;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import CucumberProject.OrangeHRM.browser;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class addmultivacancies extends browser{
	
	    @Given("^Login to HRM using \"([^\"]*)\" and \"([^\"]*)\"$")
	    public void login_to_hrm(String user, String pass) throws Throwable 
	    {
	    	driver = initialize();
	        driver.get("http://alchemy.hguy.co/orangehrm");
	        driver.findElement(By.id("txtUsername")).sendKeys(user);
	        driver.findElement(By.id("txtPassword")).sendKeys(pass);
	        driver.findElement(By.id("btnLogin")).click();
	        
	    }
	    
	    @And("^Click on recruitment page$")
	    public void click_on_recruitment_page() throws Throwable 
	    {
	        driver.findElement(By.id("menu_recruitment_viewRecruitmentModule")).click();
	    }

	    @And("^Click on vacancies link and select add$")
	    public void click_on_vacancies_link_and_select_add() throws Throwable 
	    {
	       driver.findElement(By.id("menu_recruitment_viewJobVacancy")).click();
	       driver.findElement(By.id("btnAdd")).click();
	    }
	    

	    @Then("^Provide details for vacancy \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	    public void provide_details_for_vacancy(String jobtitle, String vacancyname, String hiringmanager) throws Throwable
	    {
	    	Select jt= new Select(driver.findElement(By.id("addJobVacancy_jobTitle")));
			jt.selectByVisibleText(jobtitle);
			driver.findElement(By.id("addJobVacancy_name")).sendKeys(vacancyname);
			driver.findElement(By.id("addJobVacancy_hiringManager")).sendKeys(hiringmanager); 
	    }

	    @And("^Save the vacancies$")
	    public void save_the_vacancies() throws Throwable 
	    {
	    	driver.findElement(By.id("btnSave")).click();
	    }
	    
	    @Then("^Verify the vacancies are created$")
	    public void verify_the_vacancies_are_created() throws Throwable 
	    {
	    	 String verify =  driver.findElement(By.xpath("//div[@class='head']")).getText();
		     Assert.assertEquals(verify, "Edit Job Vacancy");
	    }

	    @And("^Make sure to close browser$")
	    public void make_sure_to_close_browser() throws Throwable 
	    {
	      driver.close(); 
	    }

}


