package stepDefinations;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import CucumberProject.OrangeHRM.browser;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class createjobvacancy extends browser {
	
	 @Given("^Launch orangeHRM$")
	    public void launch_orangehrm() throws Throwable 
	   {
	        driver = initialize();
	        driver.get("http://alchemy.hguy.co/orangehrm");
	    }

	   @And("^Login$")
	    public void login(DataTable data) throws Throwable
	    {
	        List<String> loginid = data.asList();
	        driver.findElement(By.id("txtUsername")).sendKeys(loginid.get(0));
	        driver.findElement(By.id("txtPassword")).sendKeys(loginid.get(1));
	        driver.findElement(By.id("btnLogin")).click();
	        
	    }
	   
	   @And("^Navigate to Recruitment$")
	    public void navigate_to_recruitment() throws Throwable
	   {
	        driver.findElement(By.id("menu_recruitment_viewRecruitmentModule")).click();
	    }
	    @When("^Click on vacancies$")
	    public void click_on_vacancies() throws Throwable 
	    {
	       driver.findElement(By.id("menu_recruitment_viewJobVacancy")).click();
	    }
	    @And("^Click on add$")
	    public void click_on_add() throws Throwable 
	    {
	       driver.findElement(By.id("btnAdd")).click();
	    }
	    
	    @Then("^Fill details$")
	    public void fill_details() throws Throwable 
	    {
	    	Select jt= new Select(driver.findElement(By.id("addJobVacancy_jobTitle")));
			jt.selectByValue("3");
			driver.findElement(By.id("addJobVacancy_name")).sendKeys("ABD");
			driver.findElement(By.id("addJobVacancy_hiringManager")).sendKeys("orange hrm");
		   
	    }

	    @When("^Click save button$")
	    public void click_save_button() throws Throwable 
	    {
	    	 driver.findElement(By.id("btnSave")).click();
	    }

	   

	    @Then("^Verify that the vacancy is created$")
	    public void verify_that_the_vacancy_is_created() throws Throwable 
	    {
	      String verify =  driver.findElement(By.xpath("//div[@class='head']")).getText();
	      Assert.assertEquals(verify, "Edit Job Vacancy");
	    }

	    
         @And("^Close browser$")
	    public void close_browser() throws Throwable 
	    {
	    	driver.close();
	    }


}
