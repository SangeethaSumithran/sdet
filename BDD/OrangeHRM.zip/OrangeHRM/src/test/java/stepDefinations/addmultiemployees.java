package stepDefinations;

import org.junit.Assert;
import org.openqa.selenium.By;

import CucumberProject.OrangeHRM.browser;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class addmultiemployees extends browser
{
	
	    @Given("^Launch browser and login \"([^\"]*)\" and \"([^\"]*)\"$")
	    public void launch_browser_and_login_something_and_something(String usernm, String passwd) throws Throwable 
	    {
	    	driver = initialize();
	        driver.get("http://alchemy.hguy.co/orangehrm");
	        driver.findElement(By.id("txtUsername")).sendKeys(usernm);
	        driver.findElement(By.id("txtPassword")).sendKeys(passwd);
	        driver.findElement(By.id("btnLogin")).click();
	    }
	    
	    @And("^Click on PIM option$")
	    public void click_on_pim_option() throws Throwable 
	    {
	    	Thread.sleep(1000);
	        driver.findElement(By.xpath("//*[@id=\"menu_pim_viewPimModule\"]")).click();
	    }
	    
	    @And("^Add new employee$")
	    public void add_new_employee() throws Throwable 
	    {
	     driver.findElement(By.id("btnAdd")).click();   
	    }


	    @When("^Fill details of the candidate \"([^\"]*)\" and \"([^\"]*)\"$")
	    public void fill_details_of_the_candidate_something_and_something(String firstname, String lastname) throws Throwable 
	    {
	       driver.findElement(By.xpath("//input[@id='firstName']")).sendKeys(firstname); 
	       driver.findElement(By.xpath("//input[@id='lastName']")).sendKeys(lastname); 
	       
	       
	    }
	    
	    @And("^Check createlogin details$")
	    public void check_createlogin_details() throws Throwable 
	    {
	      driver.findElement(By.xpath("//input[@id='chkLogin']")).click();  
	    }
	    
	    @And("^Provide \"([^\"]*)\"$")
	    public void provide_something(String username) throws Throwable 
	    {
	     driver.findElement(By.xpath("//input[@id='user_name']")).sendKeys(username);	
	        
	    }
	    
	    @And("^click on the save button$")
	    public void click_on_the_save_button() throws Throwable 
	    {
	        driver.findElement(By.id("btnSave")).click();
	    }
        
	    @Then("^Employees are created with \"([^\"]*)\"$")
	    public void employees_are_created_with_something(String firstname) throws Throwable
	    {
	    	String name = driver.findElement(By.xpath("//input[@id='personal_txtEmpFirstName")).getText(); 
	    	Assert.assertEquals(name, firstname);
	    }


	    @And("^browser is to be closed$")
	    public void browser_is_to_be_closed() throws Throwable 
	    {
	        driver.close();
	    }


}
