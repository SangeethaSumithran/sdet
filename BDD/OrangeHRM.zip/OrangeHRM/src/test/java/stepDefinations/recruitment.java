package stepDefinations;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import CucumberProject.OrangeHRM.browser;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class recruitment extends browser{ 
	@Given("^Launch browser and open orangeHRM page$")
    public void launch_browser_and_open_orangehrm_page() throws Throwable 
	 {
		driver = initialize();
        driver.get("http://alchemy.hguy.co/orangehrm");
     }
	
	@And("^Login \"([^\"]*)\" and \"([^\"]*)\"$")
	public void login_something_and_something(String user, String pass) throws Throwable 
	{
		driver.findElement(By.id("txtUsername")).sendKeys(user);
        driver.findElement(By.id("txtPassword")).sendKeys(pass);
        driver.findElement(By.id("btnLogin")).click();
	}
	@And("^Navigate to Recruitment and add$")
	public void navigate_to_recruitment_and_add() throws Throwable
	{
		Thread.sleep(1000);
		 driver.findElement(By.id("menu_recruitment_viewRecruitmentModule")).click();
		 driver.findElement(By.id("btnAdd")).click();
	}

     @When("^Fill details of candidate$")
     public void fill_details_of_candidate(DataTable details) throws Throwable 
     {
    	 List<String> canddetails = details.asList();
    	 driver.findElement(By.id("addCandidate_firstName")).sendKeys(canddetails.get(0));
    	 driver.findElement(By.id("addCandidate_lastName")).sendKeys(canddetails.get(1));
    	 driver.findElement(By.id("addCandidate_email")).sendKeys(canddetails.get(2));
    	 driver.findElement(By.id("addCandidate_contactNo")).sendKeys(canddetails.get(3));
    	 
         
     }
     
     @And("^Upload resume$")
     public void upload_resume() throws Throwable 
     {
    	 WebElement ele = driver.findElement(By.xpath("//input[@type='file']"));
    	 JavascriptExecutor executor = (JavascriptExecutor) driver;
    	 executor.executeScript("arguments[0].click();", ele);
    	 Thread.sleep(1000);
    	 Runtime.getRuntime().exec("C:\\Users\\SangeethaS\\Desktop\\fileupload.exe");
     }
     
     @And("^Click save$")
     public void click_save() throws Throwable 
     {
    	 Thread.sleep(2000);
    	 driver.findElement(By.id("btnSave")).click();  
     }

     @Then("^Candidate is added$")
     public void candidate_is_added() throws Throwable 
     {
      String verifycandi = driver.findElement(By.id("addCandidateHeading")).getText();
      Assert.assertEquals(verifycandi, "Candidate");
     }

     @And("^Close the browser$")
      public void close_the_browser() throws Throwable 
     {
      driver.close();
     }

}
