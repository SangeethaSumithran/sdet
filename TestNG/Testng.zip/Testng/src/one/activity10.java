package one;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class activity10 {
	WebDriver driver;
	Actions build;
	
	
	@Test
	public void middlevalue()
	{
		WebElement slider = driver.findElement(By.xpath("//input[@id='slider']"));
		build.clickAndHold(slider).moveByOffset(50, 0).release().build().perform();
		String middlevalue = driver.findElement(By.cssSelector("span#value")).getText();
		System.out.println(middlevalue);
	}
	
	@Test
	public void maxvalue()
	{
		WebElement slider = driver.findElement(By.xpath("//input[@id='slider']"));
		build.clickAndHold(slider).moveByOffset(100, 0).release().build().perform();
		String middlevalue = driver.findElement(By.cssSelector("span#value")).getText();
		System.out.println(middlevalue);
	}
	@Test
	public void minvalue()
	{
		WebElement slider = driver.findElement(By.xpath("//input[@id='slider']"));
		build.clickAndHold(slider).moveByOffset(0, 0).release().build().perform();
		String middlevalue = driver.findElement(By.cssSelector("span#value")).getText();
		System.out.println(middlevalue);	
	}
	@Test
	public void thirtymarkvalue()
	{
		WebElement slider = driver.findElement(By.xpath("//input[@id='slider']"));
		build.clickAndHold(slider).moveByOffset(30, 0).release().build().perform();
		String middlevalue = driver.findElement(By.cssSelector("span#value")).getText();
		System.out.println(middlevalue);	
	}
	@Test
	public void eightymarkvalue()
	{
		WebElement slider = driver.findElement(By.xpath("//input[@id='slider']"));
		build.clickAndHold(slider).moveByOffset(80, 0).release().build().perform();
		String middlevalue = driver.findElement(By.cssSelector("span#value")).getText();
		System.out.println(middlevalue);
	}
	
	@BeforeClass
	public void beforeclassactivity10()
	{
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\SangeethaS\\Downloads\\geckodriver.exe");
		driver=new FirefoxDriver();
		build = new Actions(driver);
		driver.get("https://www.training-support.net/selenium/sliders");
		
	}
	@AfterClass
	public void afterclassactivity10()
	{
		driver.close();
	}

}
