package one;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class activity5 {
	WebDriver driver;
	@Test(priority=1)
	public void pagetitleactivity5()
	{
	
	String title = driver.getTitle();
	System.out.println("The page title is "+title);
	Assert.assertEquals("Target Practice", title);
	}
	@Test(groups = {"HeaderTests"})
	public void thirdheaderactivity5()
	{
	String h3 = driver.findElement(By.cssSelector("h3#third-header")).getText();
	Assert.assertEquals(h3,"Third header");
	
	}
	@Test(groups = {"HeaderTests"})
	public void fifthheaderactivity5()
	{
	WebElement fifthheadercolor = driver.findElement(By.cssSelector(".ui.green.header"));
	Assert.assertEquals(fifthheadercolor.getCssValue("color"),"rgb(33, 186, 69)");
	}
	@Test(groups = {"ButtonTests"})
	public void olivebuttonactivity5()
	{
	String name = driver.findElement(By.cssSelector(".ui.olive.button")).getText();
    Assert.assertEquals(name, "Olive");
	}
	@Test(groups = {"ButtonTests"})
	public void twobuttonactivity5()
	{
		WebElement brownbutton = driver.findElement(By.cssSelector(".ui.brown.button"));
		Assert.assertEquals(brownbutton.getCssValue("color"),"rgb(255, 255, 255)");
	
	}
	@BeforeClass
	public void activity5beforeclass()
	{
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\SangeethaS\\Downloads\\geckodriver.exe");
		driver=new FirefoxDriver();
		driver.get("https://www.training-support.net/selenium/target-practice");
	}
	
	@AfterClass
	public void activity5afterclass()
	{
	driver.close();	
	}

}
