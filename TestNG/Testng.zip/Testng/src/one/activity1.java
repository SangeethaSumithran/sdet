package one;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class activity1 
{
	
	WebDriver driver;

	@Test
	public void activityone()
	{
	String title = driver.getTitle();
	Assert.assertEquals("Training Support", title);
	System.out.println("The homepage title is " +title);
	driver.findElement(By.id("about-link")).click();
	String newtitle = driver.getTitle();
	Assert.assertEquals("About Training Support", newtitle);
	System.out.print("The new title is " +newtitle);
	
	
	}
	
	
	@BeforeMethod
	public void beforemthod()
	{
	System.setProperty("webdriver.gecko.driver", "C:\\Users\\SangeethaS\\Downloads\\geckodriver.exe");
	driver=new FirefoxDriver();
    driver.get("https://www.training-support.net");
	}
	
	@AfterMethod
	public void aftermethod()
	{
		driver.close();
	}
}
