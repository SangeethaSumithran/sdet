package one;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class activity9 {
	WebDriver driver;
	@Test
	public void simpleAlertTestCase()
	{
		driver.findElement(By.xpath("//button[@id='simple']")).click();
		Reporter.log("Clicked on simple alert message");
		Alert simplealert = driver.switchTo().alert();
		Reporter.log("Simple alert message diaplayed");
		String simplemessage = simplealert.getText();
		System.out.println(simplemessage);
		Assert.assertEquals("This is a JavaScript Alert!", simplemessage);
		simplealert.accept();
		
	}
	@Test
	public void confirmAlertTestCase()
	{
		driver.findElement(By.xpath("//button[@id='confirm']")).click();
		Reporter.log("Clicked on confirm alert message");
		Alert confirmalert = driver.switchTo().alert();
		Reporter.log("Confirm alert message displayed");
		String confirmmessage = confirmalert.getText();
		System.out.println(confirmmessage);
		Assert.assertEquals("This is a JavaScript Confirmation!", confirmmessage);
		confirmalert.accept();
	}
	@Test
	public void promptAlertTestCase()
	{
		driver.findElement(By.xpath("//button[@id='prompt']")).click();
		Reporter.log("Clicked on prompt button");
		Alert promptalert = driver.switchTo().alert();
		Reporter.log("Prompt alert message diaplyed");
		String promptmmessage = promptalert.getText();
		System.out.println(promptmmessage);
		promptalert.sendKeys("accept");
		Reporter.log("Accepting the prompt alert message");
		promptalert.accept();
	}
	@BeforeMethod
	public void activity9beforetest1()
	{
		driver.switchTo().defaultContent();	
		Reporter.log("Switched to the default content");
	}
	
	@BeforeTest
	public void activity9beforetest()
	{
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\SangeethaS\\Downloads\\geckodriver.exe");
		driver=new FirefoxDriver();
		driver.get("https://www.training-support.net/selenium/javascript-alerts");
		Reporter.log("Javascript alert page is launched");
		
	}
	
	@AfterTest
	public void activity9aftertest()
	{
		driver.close();
		Reporter.log("Page is closed and testcase ended");
	}

}
