package one;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class activity3 {
	WebDriver driver;
	
	@Test
	public void oneactivity3()
	{
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("password");
		driver.findElement(By.xpath("//button[@class='ui button']")).click();
		String confirmation = driver.findElement(By.xpath("//div[@id='action-confirmation']")).getText();
		Assert.assertEquals("Welcome Back, admin", confirmation);
	}
	
	
	
	@BeforeClass
	public void beforeclassactivity3()
	{
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\SangeethaS\\Downloads\\geckodriver.exe");
		driver=new FirefoxDriver();
		driver.get("https://www.training-support.net/selenium/login-form");
		
	}
	
	@AfterClass
	public void afterclassactivity3() 
	{
	
	 driver.close();	
	}

}
