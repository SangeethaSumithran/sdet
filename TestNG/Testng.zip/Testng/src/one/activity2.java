package one;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class activity2 {
	WebDriver driver;
	
	@Test
	public void oneactivitytwo()
	{
	String title = driver.getTitle();	
	Assert.assertEquals("Target Practice", title);
	System.out.println("The title is "+title);
	}
	@Test
	public void twoactivitytwo()
	{
	WebElement button = driver.findElement(By.cssSelector(".ui.black.button"));
	 Assert.assertEquals(button.getText(), "yellow");
	 Reporter.log("This test fails");
	
	
	}
	@Test(enabled = false)
	public void threeactivitytwo()
	{
		System.out.println("Third testcase is skipped");
	}
	@Test
	public void fouractivitytwo()
	{
		String condition ="Skip";

	    if(condition.equals("Skip"))
	    {
		throw new SkipException("This is not ready for testing so skipping ");
	    }
	}
	
	@BeforeClass
	public void beforeclass()
	{
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\SangeethaS\\Downloads\\geckodriver.exe");
		driver=new FirefoxDriver();
		driver.get("https://www.training-support.net/selenium/target-practice");
	}
	
	@AfterClass
	public void afterclass()
	{
	driver.close();
	}
	

}
