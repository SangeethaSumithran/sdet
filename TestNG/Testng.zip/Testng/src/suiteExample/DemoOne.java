package suiteExample;

import org.testng.annotations.Test;

public class DemoOne {
	
	@Test
	public void firsttestcase()
	{
		System.out.println("This is first testcase of demoone class");
	}

	@Test
	public void secondtestcase()
	{
		System.out.println("This is second testcase of demoone class");
	}

}
