package suiteExample;

import org.testng.annotations.Test;

public class DemoTwo {
	
	@Test
	public void thirdtestcase()
	{
		System.out.println("This is first testcase of demotwo class");
	}

}
