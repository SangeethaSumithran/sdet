package Activity1;

import java.util.ArrayList;

public class Activity3_1 {

	public static void main(String[] args) {
		
		ArrayList<String> myList = new ArrayList<String>();
		myList.add("Kiwi");
		myList.add("Peach");
		myList.add("Avacado");
		myList.add("Pear");
		myList.add("Apple");
		System.out.println("The list of fruits are ");
		for(String s:myList)
		{
			System.out.println(s);
		}
		
		System.out.println("The third fruit is : "+myList.get(2));
		
		if(myList.contains("Apple"))
		{
			System.out.println("The mentioned fruit is present");
		}
		else
		{
			System.out.println("The mentioned fruit is not present");
		}
		System.out.println("The size of the list is : "+myList.size());
		System.out.println("The mentioned fruit is removed : " +myList.remove(3));
		System.out.println("The size of the list is : "+myList.size());
		System.out.println("The new list is :");
		for(String s:myList)
		{
			System.out.println(s);
		}
		
		
		
		
		
		

}

}