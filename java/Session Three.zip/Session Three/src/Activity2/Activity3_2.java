package Activity2;

import java.util.HashSet;
import java.util.Iterator;

public class Activity3_2 {

	public static void main(String[] args) {
		
     HashSet<String> hs = new HashSet<String>();
     hs.add("Sanitizer");
     hs.add("Germs");
     hs.add("Vaccine");
     hs.add("Corona");
     hs.add("Masks");
     hs.add("Sheild");
     System.out.println("The size of Set is : " +hs.size());
     System.out.println("The mentioned object is removed from the set : " +hs.remove("Corona"));
     if(hs.remove("Spray"))
     {
    	 System.out.println("Mentioned object is present in set to remove");
     }
     else
     {
    	 System.out.println("Mentioned object is not present in set to remove"); 
     }
     if(hs.contains("Sanitizer"))
     {
    	 System.out.println("Mentioned object is present in set");
     }
     else
     {
    	 System.out.println("Mentioned object is not present in set");
     }
     Iterator<String> iterator = hs.iterator();
     while (iterator.hasNext())
     {
    	 System.out.println(iterator.next());
     }
     
   }
	
	
}


