/**
 * 
 */
package JavaActivity1;

public class Activity1 {

	
	public static void main(String[] args) {
		Car Baleno = new Car();
		Baleno.color = "Black";
		Baleno.transmission = "Manual";
		Baleno.make = 2014;
		
		Baleno.displayCharacteristics();
		Baleno.accelarate();
		Baleno.brake();
	}

}
