package JavaActivity1;

public class Car {
	
	String color;
	String transmission;
	int make;
	int tyres;
	int doors;
	
	public Car()
	{
		tyres = 4;
		doors = 4;
	}
	
	public void displayCharacteristics()
	{
		System.out.println("Color of car is " +color);
		System.out.println("Car transmission is "+transmission);
		System.out.println("Make of car is "+make);
		System.out.println("Car has " +tyres +" tyres");
		System.out.println("Car has "+doors +" doors");
	}
	public void accelarate()
	{
		System.out.println("Car is moving forward.");
	}
    public void brake()
    {
    	System.out.println("Car has stopped.");
    }
}