package JavaActivity4;

import java.util.Arrays;

public class Activity4 {

	public static void main(String[] args) {
		int[] A = {4,3,2,10,12,1,5,6};
		int temp = 0;

			  for (int i = 0; i < A.length; i++) 
			  {     
		            for (int j = i+1; j < A.length; j++)
		            {     
		               if(A[i] > A[j])
		               {    
		                   temp = A[i];   // temp =4  
		                   A[i] = A[j];  //A[i] = 3  
		                   A[j] = temp;  //A[j] =4
		               }     
		             }
			  }
			        //Arrays.parallelSort(A);
		            System.out.println(Arrays.toString(A));
		
	}

}
	
	


