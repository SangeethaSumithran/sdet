package JavaActivity2;

public class Activity2 {

	public static void main(String[] args) {
		int[] A = {10,77,10,54,-11,10};
		int b=0;
		int sum=0;
		for (int i =0 ; i<=A.length-1;i++)
		{
		 if (A[i]==10)
		 {
			 b++;
			 sum =10*b;
		 }
		}
		if (sum==30)
		{
			System.out.println("Sum is correct");
		}
		else
		{
			System.out.println("Sum is not correct");
		}
	}

}
