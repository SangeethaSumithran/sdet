package JavaActivity3;

public class Activity3 {

	public static void main(String[] args) {
		
		double EarthSeconds = 31557600;
		double Mercury = 0.2408467;
		double Venus = 0.61519726;
		double Mars = 1.8808158;
		double Jupiter = 11.862615;
		double Saturn = 29.447498;
		double Uranus = 84.016846;
		double Neptune = 164.79132;
		double age = 1000000000;
		double earthage = age/EarthSeconds;
		System.out.println("Age on Mercury is " +earthage/Mercury +" earth years");
		System.out.println("Age on Venus is " +earthage/Venus +" earth years");
		System.out.println("Age on earth is " +earthage+" earth years");
		System.out.println("Age on Mars is " +earthage/Mars+" earth years");
		System.out.println("Age on Jupiter is " +earthage/Jupiter+" earth years");
		System.out.println("Age on Saturn is " +earthage/Saturn+" earth years");
		System.out.println("Age on Uranus is " +earthage/Uranus+" earth years");
		System.out.println("Age on Neptune is " +earthage/Neptune+" earth years");
		

		
		
	}

}
