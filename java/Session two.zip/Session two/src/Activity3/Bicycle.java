package Activity3;

public class Bicycle implements BicycleParts ,BicycleOperations{
	public int gears;
	public int currentSpeed;
	public Bicycle(int gears, int currentSpeed)
	{
		this.gears= gears;
		this.currentSpeed = currentSpeed;
	}

	public static void main(String[] args) {
		
		MoutainBike red = new MoutainBike(5, 30, 5);
		System.out.println(red.bicycleDesc());
		red.speedUp(25);
		red.applyBrake(30);

	}

	
	public void applyBrake(int decrement) {
		currentSpeed -=decrement;
		System.out.println("Current speed: " + currentSpeed);
	}


	public void speedUp(int increment) {
		currentSpeed +=increment;
		System.out.println("Current speed: " + currentSpeed);
		
	}
	
	public String bicycleDesc()
	{
		return ("The number of gears are "+ gears + " and the Speed of bicycle is " + currentSpeed );
		
	}

}
