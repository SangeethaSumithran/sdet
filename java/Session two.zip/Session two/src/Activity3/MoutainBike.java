package Activity3;

public class MoutainBike extends Bicycle{
    public int seatHeight;
	public MoutainBike(int gears, int currentSpeed, int height) {
		super(gears, currentSpeed);
		seatHeight = height;
		// TODO Auto-generated constructor stub
	}
	
	public void setHeight(int newValue)
	{
		seatHeight = newValue;
	}
	
	public String bicycleDesc() {
        return (super.bicycleDesc() + " Seat height is "+seatHeight);
	}

}
