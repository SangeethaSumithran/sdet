package Activity2;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Plane {
	
	private List<String> passengers;
	private int maxPassengers;
	private Date lastTimeTookOf;
	private Date lastTimeLanded;
	    
	    public Plane(int maxPassengers) //get the maximum passengers
	    {
	    	this.maxPassengers = maxPassengers;
	    	this.passengers= new ArrayList<>();
	    	
	    }
	    
	    public void onboard(String passenger) //to add passanger
	    {
			this.passengers.add(passenger);
	    }
	    
	    public Date takeOff() //the takeoff time
	    {
	    	this.lastTimeTookOf = new Date();
	    	return lastTimeTookOf;
	    		
	    }
	    
	    public void land() //clear passangers data after landing
	    {
	    	this.lastTimeLanded = new Date();
	    	this.passengers.clear();
	    }
	    public Date getLastTimeLanded() // get the landed time
	    {
	    	return lastTimeLanded ;
	    }
	    
	    public List<String> getPassesngers() // get list of passanger
	    {
	    	return passengers;
	    }
}
	