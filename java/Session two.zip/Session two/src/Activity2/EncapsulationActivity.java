package Activity2;

public class EncapsulationActivity {

	public static void main(String[] args) throws InterruptedException  {
		
		Plane plane = new Plane(7);
		plane.onboard("Sangeetha");
		plane.onboard("Anirudh");
		plane.onboard("Ayaansh");
		plane.onboard("Aneesh");
		plane.onboard("Sruthi");
		System.out.println("Time when the plane tookoff is " +plane.takeOff());
		System.out.println("The list of passangers is " +plane.getPassesngers());
		Thread.sleep(5000);
		plane.land();
		System.out.println("Time when the plane has landed is " +plane.getLastTimeLanded());
		System.out.println("The list of passangers after landing is " +plane.getPassesngers());
	}

}
