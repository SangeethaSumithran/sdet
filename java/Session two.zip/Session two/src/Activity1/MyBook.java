package Activity1;

public class MyBook extends Book {

	@Override
	void setTitle(String s) {
		title = s;
		
	}

	
		
	}

