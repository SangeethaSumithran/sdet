package Activity1;

public class Activity2_1 {

	public static void main(String[] args) {
		
		String title = "The Alchemist";
		MyBook newNovel = new MyBook();
		newNovel.setTitle(title);
		System.out.println(newNovel.getTitle());
		
	}

}
