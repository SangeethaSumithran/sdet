package Activity1;

public abstract class Book {
	String title;
	
	 abstract void setTitle(String s);
	 
	 public String getTitle()
	 {
		 return title;
	 }
	 
	
}