/**
 * 
 */
package Activity4;


public class Activity2_4 {
	
	
	public static void main(String[] args)  {
		try
		{
		Activity2_4.exceptionTest("This is the message expected for not null");
		Activity2_4.exceptionTest(null);
		}
		catch(CustomException cs)
		{
			System.out.println("This is the custom error in Catch block : " + cs.getMessage());
		}
		

	}
	static void exceptionTest(String s) throws CustomException
	{
		if (s==null)
		{
			 throw new CustomException("The message is null");
		}
		else 
		{
			System.out.println(s);
		}
	}

}



