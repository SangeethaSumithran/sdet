package jobportal;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class jobpostingpage
{
	public WebDriver driver;
	
	By email = By.xpath("//input[@id='create_account_email']");
	By jtitle = By.xpath("//input[@id='job_title']");
	By Jtype = By.xpath("//*[@id='job_type']");
	By frame = By.id("job_description_ifr");
	By desc = By.xpath("//*[@id='tinymce']");
	By appemail = By.xpath("//input[@id='application']");
	By comp = By.xpath("//input[@id='company_name']");
	By prebut = By.xpath("//input[@class='button']");
	By subbut = By.xpath("//input[@id='job_preview_submit_button']");
	By viewlist = By.xpath("//div[@class='entry-content clear']/a");
	public jobpostingpage(WebDriver driver) 
	{
		this.driver=driver; 
	}
	
	public WebElement postemail()
	{
		return driver.findElement(email);
	}
	 
	public WebElement jobtitlejp()
	{
		return driver.findElement(jtitle);
	}
	public WebElement jobtypejp()
	{
		return driver.findElement(Jtype);
	}
	public WebElement descframe()
	{
		return driver.findElement(frame);
	}
	public WebElement descriptionjp()
	{
		return driver.findElement(desc);
	}
	public WebElement appemailjp()
	{
		return driver.findElement(appemail);
	}
	public WebElement companynamejp()
	{
		return driver.findElement(comp);
	}
	public WebElement previewbuttonjp()
	{
		return driver.findElement(prebut);
	}
	public WebElement submitbuttonjp()
	{
		return driver.findElement(subbut);
	}
	public WebElement viewlistingjp()
	{
		return driver.findElement(viewlist);
	}
}
