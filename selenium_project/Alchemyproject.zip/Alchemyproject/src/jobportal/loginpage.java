package jobportal;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class loginpage {
	public WebDriver driver;
	
	By user = By.xpath("//input[@id='user_login']");
	By pass = By.xpath("//input[@id='user_pass']");
	By loginbut = By.xpath("//input[@id='wp-submit']");
	By loginconfirm = By.xpath("//div[@class='wrap']/h1");
	By jobp = By.xpath("//ul[@id='adminmenu']/li[7]");
	By addnew = By.xpath("//a[@class='page-title-action']");
	By position = By.id("post-title-0");
	By jobt = By.id("in-job_listing_type-6");
	By jobpublish = By.xpath("//div[@class='edit-post-header__settings']/button[2]");
	By publishagain = By.xpath("//div[@class='editor-post-publish-panel']/div/div/button");
	public loginpage (WebDriver driver)
	{
		this.driver=driver;
	}
	
	public WebElement usernamelin()
	{
		return driver.findElement(user);
	}
	public WebElement passwordlin()
	{
		return driver.findElement(pass);
	}
	public WebElement loginbuttonlin()
	{
		return driver.findElement(loginbut);
	}
	public WebElement loginconfirmlin()
	{
		return driver.findElement(loginconfirm);
	}
	public WebElement loginjobpost()
	{
		return driver.findElement(jobp);
	}
	public WebElement addnewjob()
	{
		return driver.findElement(addnew);
	}
	public WebElement positionjp()
	{
		return driver.findElement(position);
	}
	public WebElement typejob()
	{
		return driver.findElement(jobt);
	}
	public WebElement publishjob()
	{
		return driver.findElement(jobpublish);
	}
	public WebElement publishjobagain()
	{
		return driver.findElement(publishagain);
	}

}
