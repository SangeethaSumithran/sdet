package jobportal;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class mainpage {

	public WebDriver driver;
	By headingone = By.xpath("//h1[@class='entry-title']");
	By urlimage = By.xpath("//div[@class='post-thumb-img-content post-thumb']/img");
	By headingtwo = By.xpath("//div[@class='entry-content clear']/h2");
	By jobslink = By.xpath("//li[@id='menu-item-24']/a");
	By jobpostinglink = By.xpath("//li[@id='menu-item-26']/a");
	public mainpage(WebDriver driver) 
	{
		this.driver=driver; 
	}
	
	public WebElement oneheading()
	{
		return driver.findElement(headingone);
	}
	
	public WebElement image()
	{
		return driver.findElement(urlimage);
	}
	public WebElement twoheading()
	{
		return driver.findElement(headingtwo);
	}
	public WebElement linkjobs()
	{
		return driver.findElement(jobslink);
	}
	public WebElement jobpostings()
	{
		return driver.findElement(jobpostinglink);
	}
	
	

}
