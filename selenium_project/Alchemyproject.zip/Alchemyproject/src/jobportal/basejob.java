package jobportal;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class basejob
{
	
	public WebDriver driver;
	public Properties p;
	public WebDriver initilizebrowser() throws IOException 
	{
        p = new Properties();
		FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"\\src\\jobportal\\data.properties");
		p.load(fs);
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\SangeethaS\\Downloads\\geckodriver.exe");
		driver=new FirefoxDriver();	
		return driver;
		
	}
	public String screenshot(String testCaseName , WebDriver driver) throws IOException
	{
		TakesScreenshot sc = (TakesScreenshot) driver;
		File source = sc.getScreenshotAs(OutputType.FILE);
		String destinationFile = System.getProperty("user.dir")+"\\reports\\"+testCaseName+".png";
		FileUtils.copyFile(source,new File(destinationFile));
		return destinationFile;
		
	}
	
	

}
