package jobportal;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class jobspage {
	public WebDriver driver;
	
	By keyword = By.xpath("//input[@id='search_keywords']");
	By search = By.xpath("//div[@class='search_submit']/input");
	By jobpost = By.xpath("//ul[@class='job_listings']/li");
	By applybuttonjob = By.xpath("//input[@class='application_button button']");
	By applyemailjob = By.xpath("//a[@class='job_application_email']");
	By entrytit = By.xpath("//h1[@class='entry-title']");
	By jobdes = By.xpath("//div[@class='job_description']");
	
	public jobspage(WebDriver driver) 
	{
		this.driver=driver; 
	}
	
	public WebElement keywordsearch()
	{
		return driver.findElement(keyword);
	}
	
	public WebElement searchjobs()
	{
		return driver.findElement(search);
	}
	public WebElement jobinfo()
	{
		return driver.findElement(jobpost);
	}
	public WebElement jobapply()
	{
		return driver.findElement(applybuttonjob);
	}
	public WebElement applyemail()
	{
		return driver.findElement(applyemailjob);
	}
	public WebElement entrytitlejob()
	{
		return driver.findElement(entrytit);
	}
	public WebElement jobdescjob()
	{
		return driver.findElement(jobdes);
	}
	
	
}
