package testcaseforjobportal;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


import jobportal.basejob;
import jobportal.jobpostingpage;
import jobportal.jobspage;
import jobportal.mainpage;

public class jobspostingtestcases extends basejob{
    WebDriver driver;
    mainpage mp;
	jobspage jp;
	jobpostingpage jpost;
    
    @BeforeMethod
	public void openbrowser() throws IOException
	{
		driver = initilizebrowser();
		driver.get(p.getProperty("url"));	
		driver.manage().window().maximize();
	}
    
	
	@Test
	public void jobposting()
	{
		mp = new mainpage(driver);
	    jp = new jobspage(driver);
		jobpostingpage jpost = new jobpostingpage(driver);
		driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
		mp.jobpostings().click();
		jpost.postemail().sendKeys("nev@ris.com");
		jpost.jobtitlejp().sendKeys("SDET Tester");
		Select s= new Select(jpost.jobtypejp());
		s.selectByVisibleText("Internship");
		WebElement description= jpost.descframe();
		driver.switchTo().frame(description);
		jpost.descriptionjp().sendKeys("abcd");
		driver.switchTo().defaultContent();
		jpost.appemailjp().sendKeys("cirf@in.com");
		jpost.companynamejp().sendKeys("jim");
		jpost.previewbuttonjp().click();
		jpost.submitbuttonjp().click();
		jpost.viewlistingjp().click();
		String entrytitle = jp.entrytitlejob().getText();
		Assert.assertEquals(entrytitle, "SDET Tester");
		String jobdesc = jp.jobdescjob().getText();
		Assert.assertEquals(jobdesc, "abcd");
		jp.jobapply().click();
		jp.applyemail().getText();
		mp.linkjobs().click();
		String jobinfotext = jp.jobinfo().getText();
		System.out.println(jobinfotext);
		Reporter.log("Job posting is successful");
		}
		
	@AfterMethod
	public void closebrowser()
	{
		driver.close();
	}
	
}
