package testcaseforjobportal;

import java.io.IOException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import jobportal.basejob;
import jobportal.loginpage;

public class adminpagetestcase extends basejob{
	
	@BeforeMethod
	public void openbrowser2() throws IOException
	{
		driver = initilizebrowser();
		driver.get(p.getProperty("url2"));
		driver.manage().window().maximize();
		
	}
	@Test
	@Parameters({"username","password"})
	public void testcaseeightlogin(String username,String password)
	{
		loginpage lgpage = new loginpage(driver);
		lgpage.usernamelin().sendKeys(username);
		lgpage.passwordlin().sendKeys(password);
		lgpage.loginbuttonlin().click();
		String lgconfirm = lgpage.loginconfirmlin().getText();
		Assert.assertEquals("Dashboard", lgconfirm);
		Reporter.log("Logged in successfully");
	}
	@Test
	@Parameters({"username","password"})
	public void testcaseninelogin(String username,String password)
	{
		loginpage lgpage = new loginpage(driver);
		lgpage.usernamelin().sendKeys(username);
		lgpage.passwordlin().sendKeys(password);
		lgpage.loginbuttonlin().click();
		String lgconfirm = lgpage.loginconfirmlin().getText();
		Assert.assertEquals("Dashboard", lgconfirm);
		Reporter.log("Logged in successfully");
		lgpage.loginjobpost().click();
		lgpage.addnewjob().click();
		lgpage.positionjp().sendKeys("SDET");
		lgpage.typejob().click();
		lgpage.publishjob().click();
		lgpage.publishjobagain().click();
		Reporter.log("Posed a job after logging in");
	}
	
	
	
	@AfterMethod
	public void loginpageafter()
	{
		driver.close();
	}
	
	

}
