package testcaseforjobportal;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


import jobportal.basejob;
import jobportal.jobspage;
import jobportal.mainpage;

public class jobslinktestcase extends basejob {

	mainpage mp;
	jobspage jp;
	
	WebDriver driver;
	
	@BeforeMethod
	public void openbrowser() throws IOException
	{
		driver = initilizebrowser();
		driver.get(p.getProperty("url"));
		driver.manage().window().maximize();
		
	}
	@Test
	public void jobs() throws InterruptedException
	{
		mainpage mp = new mainpage(driver);
		mp.linkjobs().click();
		String jobtitle = driver.getTitle();
		System.out.println("Title of jobs page is "+jobtitle);
		Reporter.log("Jobs page title is printed successfully");
	}
	
	@Test
	public void navigatejob() throws InterruptedException
	{
		mp = new mainpage(driver);
		jp = new jobspage(driver);
		mp.linkjobs().click();
		jp.keywordsearch().sendKeys("SDET Tester");
		Thread.sleep(3000);
		jp.searchjobs().click();
		Thread.sleep(3000);
		jp.jobinfo().click();
		Thread.sleep(3000);
		jp.jobapply().click();
		String email = jp.applyemail().getText();
		System.out.println(email);
		Reporter.log("Jobs search is successful");
	}
	
	@AfterMethod
	public void closebrowser()
	{
		driver.close();
	}
}
