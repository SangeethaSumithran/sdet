package testcaseforjobportal;


import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import jobportal.basejob;
import jobportal.jobpostingpage;
import jobportal.jobspage;
import jobportal.mainpage;


public class mainpagetestcase extends basejob{
	
	
	mainpage mp;
	jobspage jp;
	jobpostingpage jpost;
	WebDriver driver;
	

	
	@BeforeMethod
	public void openbrowser() throws IOException
	{
		driver = initilizebrowser();
		driver.get(p.getProperty("url"));
		driver.manage().window().maximize();
	}
	
	@Test
	public void getTitle()
	{
		mp = new mainpage(driver);
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title, "Alchemy Jobs � Job Board Application");
		Reporter.log("Job title is matching");
	}
	
	@Test
	public void firstheading()
	{
		mp = new mainpage(driver);
		String header = mp.oneheading().getText();
		System.out.println("The first heading is " +header);
		Assert.assertEquals(header, "Welcome to Alchemy Jobs");
		Reporter.log("First heading is matching");
	}
	
	@Test
	public void imageurl()
	{
		mp = new mainpage(driver);
		String getimageurl = mp.image().getAttribute("src");
		System.out.println(getimageurl);
		Reporter.log("Image URL is matching");
	}
	
	@Test
	public void secondheading()
	{
		mp = new mainpage(driver);
		String secondheading = mp.twoheading().getText();
		System.out.println("The second heading is " +secondheading);
		Reporter.log("Second heading is matching");
	}
	
	@AfterMethod
	public void closebrowser()
	{
		driver.close();
	}
	
	
	

}
