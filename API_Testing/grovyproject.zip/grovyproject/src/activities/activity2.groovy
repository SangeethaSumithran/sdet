package activities

class activity2 {
	static main (def args)
	{
	def marks = [99,45,32,88,75]	
	def grade = "A", avg = 0 , sum = 0
	marks.each { sum+=it }
	avg = sum/marks.size() as Integer
	switch (avg)
	{
		case 90..100:
		grade = "A"
		break
		
		case 80..89:
		grade = "B"
		break
		
		case 70..89:
		grade = "C"
		break
		
		case 50..69:
		grade = "D"
		break
		
		case 0..49:
		grade = "F"
		break
		
		default :
		println "Type valid number"
	
	}
	println "The total sum obtained by student is : " +sum
	 println "The maximum marks obtained by student is : " +marks.max()
	 println "The minimum marks obtained by student is : " +marks.min()
	 println "The average marks obtained by student is : " +avg
	 println "The grade obtained by student is : " +grade
	 
	
}
}
