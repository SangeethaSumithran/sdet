package activities

class activity7 {

	public static void main(String[] args)
		{
		   File file = new File("C:/Users/SangeethaS/Desktop/selinium/sample.txt");
	       file.createNewFile();
	       file.write("A Quick Brown Fox Jumped Over The Lazy Cow\n")
	       file.append("John Jimbo jingeled happily ever after\n")
	       file.append("Th1\$ 1\$ v3ry c0nfu51ng")
		   
		   file.eachLine 
		   { line->
			   if(line ==~ /.*Cow$/)
			   {
				println line
			   }
			}
		   
			file.eachLine 
			{ line->
			if(line==~ /^J.*/)
				{
				println line
				}
			}
			file.eachLine
			{ line->
			if(line ==~ /.*\d\d.*/)
				{
				println line
				}
			}
		  def matchone = file.getText() =~ /\S+er/
		  if (matchone)
		  {
			  println "Its matched"
			  println "String matching '/\\S+er/' are: ${matchone.findAll()}"
		  }
		  else
		  {
			  println"Its not matching"
		  }
          
		  def matchtwo = file.getText() =~ /\S*\d\W/
		  if(matchtwo)
		  {
			  println "Its matched"
			  println "String matching '/\\S*\\d\\W/' are: ${matchtwo.findAll()}"
		  }
		  else
		  {
			  println "Its not matched"
		  }	
			
		}
	}
