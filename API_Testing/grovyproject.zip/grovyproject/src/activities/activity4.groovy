package activities

class activity4 {
	static main (def args)
	{
		def String = "This is a Groovy language"
		println "The reversed string is : " +String.reverse()
		println "The Substring is : " +String.substring(10)
		println "The Sring after minus Groovy is : " +String -"Groovy"
		println "The String in lowercase is : " +String.toLowerCase()
		println "The String in upper case is : " +String.toUpperCase()
		
		if (String.matches("(.*)one(.*)"))
			println "String matched"
		else
			println "String not matched"
		
		
		println "The string after replacing groovy is : " +String.replaceAll("Groovy","highlevel groovy")
		println "Even after replacing the original String will not be changed and will be same as : " +String
		
	}
}
