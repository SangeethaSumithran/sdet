package activities

class activity1 {
	static main (args)
	{
		def x
		int y
		def array = [18,2.5,"Sangeetha", false, x, y]
		array.each { println "The value is : "+it + " and the type of each variable is:  "+it.getClass() }
	}
}
