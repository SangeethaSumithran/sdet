package activities

class activity5 {
	static void main(String[] args)
	{
		def completelist = [11, 2, 19, 5, "Mango", "Apple", "Watermelon"]
		def intlist = completelist - ["Mango", "Apple", "Watermelon"]
		def strlist = completelist - [11, 2, 19, 5]
		println "The sortedt integer list is : " +intlist.sort()
		println "The sorted string list is : " +strlist.sort()
		
	}
}
