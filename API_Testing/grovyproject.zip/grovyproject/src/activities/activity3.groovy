package activities

class activity3 {
	static main (def args)
	{
		def a = 0 , b=1 , count = 10
		print a
		count.times 
		{ 
			(a,b)=[b,a+b]
			print "," +a
		}
		
	}
}
