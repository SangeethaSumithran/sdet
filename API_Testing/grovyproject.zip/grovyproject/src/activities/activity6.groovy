package activities

class activity6 {
	static void main(String[] args)
	{
		def firstmap = [:]
		firstmap.put(1, "Dog")
		firstmap.put(2, "Horse")
		firstmap.put(3, "Wolves")
		
		def secondmap = [4:"Cat" , 5:"Mouse"]
		def newmap = firstmap.plus(secondmap)
		println "The new map details are : " +newmap
		println "The sorted new map values are : " +newmap.values().sort { it.length() }
		
	}
}
